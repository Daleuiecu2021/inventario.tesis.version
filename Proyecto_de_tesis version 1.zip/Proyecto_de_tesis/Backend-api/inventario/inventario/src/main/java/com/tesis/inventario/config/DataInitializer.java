package com.tesis.inventario.config;

import java.math.BigDecimal;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.tesis.inventario.entity.Categoria;
import com.tesis.inventario.entity.Producto;
import com.tesis.inventario.entity.Usuario;
import com.tesis.inventario.repository.CategoriaRepository;
import com.tesis.inventario.repository.ProductoRepository;
import com.tesis.inventario.repository.UsuarioRepository;

@Component
public class DataInitializer implements CommandLineRunner {
    
     private final UsuarioRepository usuarioRepository;
    private final CategoriaRepository categoriaRepository;
    private final ProductoRepository productoRepository;
    private final PasswordEncoder passwordEncoder;

    // Constructor con todas las dependencias requeridas
    public DataInitializer(UsuarioRepository usuarioRepository, 
                           CategoriaRepository categoriaRepository, 
                           ProductoRepository productoRepository, 
                           PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.categoriaRepository = categoriaRepository;
        this.productoRepository = productoRepository;
        this.passwordEncoder = passwordEncoder;
    }

      @Override
        public void run(String... args) throws Exception {
        // Verificamos si ya existe el usuario de la tesis para no duplicarlo
        if (usuarioRepository.findByUsername("admin").isEmpty()) {
            
            Usuario admin = new Usuario();
            admin.setUsername("admin");
            // El mismo componente BCrypt se encargará de generar el hash perfecto sin errores
            admin.setPassword(passwordEncoder.encode("admin123")); 
            admin.setNombre("Denis Administrador");
            admin.setRol("ADMINISTRADOR");
            admin.setActivo(true);

            usuarioRepository.save(admin);
            System.out.println("✅ [TESIS] Usuario 'admin' creado con éxito en PostgreSQL desde código.");
        }

        // 2. Inicializar una Categoría base para el Inventario
        Categoria tecnologia = null;
        if (categoriaRepository.findAll().isEmpty()) {
            tecnologia = new Categoria();
            tecnologia.setNombre("Tecnología");
            tecnologia.setDescripcion("Equipos electrónicos y computación");
            tecnologia = categoriaRepository.save(tecnologia);
            System.out.println("✅ [TESIS] Categoría 'Tecnología' creada.");
        } else {
            tecnologia = categoriaRepository.findAll().get(0);
        }

        // 3. Inicializar un Producto de prueba relacional
        if (productoRepository.findAll().isEmpty()) {
            Producto laptop = new Producto();
            laptop.setCodigo("PROD-001");
            laptop.setNombre("Laptop ASUS Vivobook");
            laptop.setDescripcion("Intel Core i5, 16GB RAM, 512GB SSD");
            laptop.setPrecio(new BigDecimal("750.00"));
            laptop.setStock(10);
            laptop.setCategoria(tecnologia); // Mapeo de la llave foránea
            
            productoRepository.save(laptop);
            System.out.println("✅ [TESIS] Producto inicial 'Laptop ASUS' guardado con éxito.");
        }
    }

}

package com.tesis.inventario.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;


@Configuration
@EnableWebSecurity
public class SecurityConfig {

    // Componente encargado de encriptar y verificar contraseñas de forma segura
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

 @Bean
public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    http
        .cors(cors -> {}) // Déjalo así vacío, Spring buscará un filtro global automático
        .csrf(csrf -> csrf.disable())
        .authorizeHttpRequests(auth -> auth
            .requestMatchers("/api/test/**").permitAll()
            .requestMatchers("/api/admin/**").hasAuthority("ADMINISTRADOR")
            .requestMatchers("/api/inventario/**").hasAnyAuthority("ADMINISTRADOR", "OPERADOR")
            .anyRequest().authenticated()
        )
        .httpBasic(basic -> {}); 

    return http.build();
}

}

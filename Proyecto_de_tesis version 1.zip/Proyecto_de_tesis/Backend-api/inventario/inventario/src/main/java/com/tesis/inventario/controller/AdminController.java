package com.tesis.inventario.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @GetMapping("/dashboard")
    public Map<String, String> accederAlPanel() {
        Map<String, String> respuesta = new HashMap<>();
        respuesta.put("estado", "CONCEDIDO");
        respuesta.put("mensaje", "Bienvenido al Panel de Administración Seguro de la Intranet");
        return respuesta;
    }
}
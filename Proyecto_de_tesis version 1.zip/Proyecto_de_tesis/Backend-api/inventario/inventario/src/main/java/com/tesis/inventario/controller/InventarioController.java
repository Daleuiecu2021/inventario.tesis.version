package com.tesis.inventario.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/inventario")
public class InventarioController {

    @GetMapping("/productos")
    public Map<String, String> verProductos() {
        Map<String, String> respuesta = new HashMap<>();
        respuesta.put("estado", "EXITOSO");
        respuesta.put("mensaje", "Acceso concedido al catálogo de productos (Visible para Admin y Operador).");
        return respuesta;
    }
}
package com.tesis.inventario.controller;


import com.tesis.inventario.entity.Producto;
import com.tesis.inventario.service.ProductoService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/inventario/productos")
public class ProductoController {
    
    private final ProductoService productoService;

    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    // Endpoint para listar productos (Accesible por ADMIN y OPERADOR según tu SecurityConfig)
    @GetMapping
    public List<Producto> listarProductos() {
        return productoService.obtenerTodos();
    }

    // Endpoint para registrar un producto (Accesible por ADMIN y OPERADOR)
    @PostMapping
    public Producto crearProducto(@RequestBody Producto producto) {
        return productoService.guardar(producto);
    }
}

package com.tesis.inventario.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/test")
@CrossOrigin(origins = "*")     // Permite que cualquier frontedn de la intranet se conecta
public class TestController {

    @GetMapping("/conexion")
    public Map<String, String> verificarConexion() {
        Map<String, String> respuesta = new HashMap<>();
        respuesta.put("estado", "EXITOSO");
        respuesta.put("mensaje", "El backend en Spring boot responde correctamente");
        respuesta.put("sistema_opertativo", System.getProperty("os.name"));
        return respuesta;
    }
    
}

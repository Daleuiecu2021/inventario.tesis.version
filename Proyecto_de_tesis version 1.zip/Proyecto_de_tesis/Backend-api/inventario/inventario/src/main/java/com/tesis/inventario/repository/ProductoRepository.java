package com.tesis.inventario.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tesis.inventario.entity.Producto;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long>{
    Optional<Producto> findByCodigo(String codigo);
}

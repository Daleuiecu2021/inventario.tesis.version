package com.tesis.inventario.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tesis.inventario.entity.Producto;
import com.tesis.inventario.repository.ProductoRepository;

@Service
public class ProductoService {
    
    private final ProductoRepository productoRepository;

    public ProductoService(ProductoRepository productoRepository){
        this.productoRepository = productoRepository;
    }

    public List<Producto> obtenerTodos(){
        return productoRepository.findAll();
    }

    // Regla de Negocio: Guardar producto validando que el código sea único para la tesis

    public Producto guardar(Producto producto){
        if (productoRepository.findByCodigo(producto.getCodigo()).isPresent()){
            throw new RuntimeException("El codigo de producto '" + producto.getCodigo() + "' ya existe en el inventario.");
        }
        return productoRepository.save(producto);
    }        
}
